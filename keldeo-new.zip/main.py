import re, os, asyncio, random, string, keep_alive, discord

from discord.ext import commands, tasks

version = 'v2.7'

user_token = os.environ['user_token']
spam_id = os.environ['spam_id']
catch_id = os.environ['catch_id']
user_id = os.environ['user_id']
user_id = os.environ.get('user_id')
user_id = int(user_id)

with open('data/pokemon', 'r', encoding='utf8') as file:
    pokemon_list = file.read()
with open('data/legendary', 'r') as file:
    legendary_list = file.read()
with open('data/mythical', 'r') as file:
    mythical_list = file.read()
with open('data/level', 'r') as file:
    to_level = file.readline()

num_pokemon = 0
shiny = 0
legendary = 0
mythical = 0

poketwo = 716390085896962058
client = commands.Bot(command_prefix='~')
intervals = [3.0, 2.2, 2.4, 2.6, 2.8]


def solve(message):
    hint = []
    for i in range(15, len(message) - 1):
        if message[i] != '\\':
           hint.append(message[i])
    hint_string = ''
    for i in hint:
        hint_string += i
    hint_replaced = hint_string.replace('_', '.')
    solution = re.findall('^' + hint_replaced + '$', pokemon_list,
                          re.MULTILINE)
    return solution


@tasks.loop(seconds=random.choice(intervals))
async def spam():
    channel = client.get_channel(int(spam_id))
    await channel.send(''.join(
        random.sample(['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'], 7) *
        5))


@spam.before_loop
async def before_spam():
    await client.wait_until_ready()


spam.start()


@client.event
async def on_ready():
    print('Bot is ready!')
    await client.change_presence(status=discord.Status.offline)


@client.event
async def on_message(message):
    channel = client.get_channel(int(catch_id))
    if message.channel.id == int(catch_id):
        if message.author.id == poketwo:
            if message.embeds:
                embed_title = message.embeds[0].title
                if 'wild pokémon has appeared!' in embed_title:
                    spam.cancel()
                    await asyncio.sleep(4)
                    await channel.send('<@716390085896962058> h')
                elif "Congratulations" in embed_title:
                    embed_content = message.embeds[0].description
                    if 'now level' in embed_content:
                        split = embed_content.split(' ')
                        a = embed_content.count(' ')
                        level = int(split[a].replace('!', ''))
                        if level == 100:
                            await channel.send(f".s {to_level}")
                            with open('data/level', 'r') as fi:
                                data = fi.read().splitlines(True)
                            with open('data/level', 'w') as fo:
                                fo.writelines(data[1:])
            else:
                content = message.content
                if 'The pokémon is ' in content:
                    if not len(solve(content)):
                        print('Pokemon not found.')
                    else:
                        for i in solve(content):
                            await asyncio.sleep(6)
                            await channel.send(f'<@716390085896962058> c {i}')
                    check = random.randint(1, 60)
                    if check == 1:
                        await asyncio.sleep(900)
                        spam.start()
                    else:
                        await asyncio.sleep(1)
                        spam.start()

                elif 'Congratulations' in content:
                    global shiny
                    global legendary
                    global num_pokemon
                    global mythical
                    num_pokemon += 1
                    split = content.split(' ')
                    pokemon = split[7].replace('!', '')
                    if 'seem unusual...' in content:
                        shiny += 1
                        print(f'Shiny Pokémon caught! Pokémon: {pokemon}')
                        print(
                            f'Shiny: {shiny} | Legendary: {legendary} | Mythical: {mythical}'
                        )
                    elif re.findall('^' + pokemon + '$', legendary_list,
                                    re.MULTILINE):
                        legendary += 1
                        print(f'Legendary Pokémon caught! Pokémon: {pokemon}')
                        print(
                            f'Shiny: {shiny} | Legendary: {legendary} | Mythical: {mythical}'
                        )
                    elif re.findall('^' + pokemon + '$', mythical_list,
                                    re.MULTILINE):
                        mythical += 1
                        print(f'Mythical Pokémon caught! Pokémon: {pokemon}')
                        print(
                            f'Shiny: {shiny} | Legendary: {legendary} | Mythical: {mythical}'
                        )
                    else:
                        print(f'Total Pokémon Caught: {num_pokemon}')
                elif 'human' in content:
                    spam.cancel()
                    await channel.send(
                        '<@843330164355366943> Captcha detected; autocatcher paused. Press enter to restart, after solving captcha manually.'
                    )
                    input()
                    await channel.send('<@716390085896962058> h')
    if not message.author.bot:
        await client.process_commands(message)


@client.command()
async def t(ctx, number: int, help='For Simple Trading'):
    user = client.get_user(user_id)

    if not user:
        print("Could not find user.")
        return

    if ctx.author.id == user_id:
        response = f'<@716390085896962058> t {ctx.author.mention}'
        tradeadd = f'<@716390085896962058> t add {number}'
        confirm = f'<@716390085896962058> t c'
        await ctx.send(response)
        await asyncio.sleep(8)
        await ctx.send(tradeadd)
        await asyncio.sleep(8)
        await ctx.send(confirm)
    else:
        print("This command is not allowed for your user ID.")


@t.error
async def t_error(ctx, error):
    if isinstance(error, commands.errors.BadArgument):
        await ctx.send("Please enter a valid number.")


# Remove the default help command
client.remove_command('help')


@client.command(name='help', help='Shows this')
async def help_command(ctx, command_name=None):
    # Replace USER_ID with the ID of the desired user
    if ctx.author.id != user_id:
        return

    if not command_name:
        # Display a list of all available commands and their descriptions
        message = '***List of Available Commands:\n***'
        for command in client.commands:
            if not command.hidden:
                message += f'{command.name}: {command.help}\n'
        await ctx.send(message)
    else:
        # Display help information for a specific command
        command = client.get_command(command_name)
        if not command:
            await ctx.send(f"Command `{command_name}` not found.")
        else:
            message = f"Help: {command.name}\n\n"
            message += f"Description: {command.help}\n"
            if command.usage:
                message += f"Usage: {command.usage}\n"
            await ctx.send(message)


@client.command()
async def say(ctx, *, arg=None, help="The bot says the exact you say"):
    if ctx.author.id == user_id:
        if arg is None:
            await ctx.send('`→ Say something, you dum!`')
        else:
            try:
                await ctx.send(arg)
            except:
                await ctx.send('`→ Error sending message.`')
    else:
        print("Wrong owner")


@client.command()
async def show(ctx, *, text, help="To check if you have a dam pokemon or not"):
    if ctx.author.id != user_id:
        await print("This command is not allowed for your user ID.")
        return

    if text.lower() == 'rare':
        await asyncio.sleep(2)
        await ctx.send('<@716390085896962058>p --leg --myth --ub')
    elif text.lower() == 'iv':
        await asyncio.sleep(2)
        await ctx.send('<@716390085896962058>p --iv >90')
        await asyncio.sleep(5)
        await ctx.send('<@716390085896962058>p --iv <10')
    elif text.lower() == 'sh':
        await asyncio.sleep(2)
        sh = "<@716390085896962058>p --sh"
        await ctx.send(sh)

    elif text.lower() == 'duelish':
        await asyncio.sleep(2)
        duelish = "<@716390085896962058>p --spdiv 31 --iv >80"
        await ctx.send(duelish)
      
    elif text.lower() == 'p':
        await asyncio.sleep(2)
        p = "<@716390085896962058>p"
        await ctx.send(p)

    else:
        await ctx.send("type either &show iv or rares or sh or duelish")




@client.command()
async def bal(ctx):
    user = client.get_user(user_id)

    if not user:
        print("Could not find user.")
        return

    if ctx.author.id == user_id:
        lolp = "<@716390085896962058>bal"
        await ctx.send(lolp)
    else:
        print("This command is not allowed for your user ID.")


@client.command()
async def react(ctx):
    # Check if the user ID matches the allowed user ID
    if ctx.author.id != user_id:
        await ctx.print("Sorry, you are not allowed to use this command.")
        return

    # Get the message above the command
    messages = await ctx.channel.history(limit=2).flatten()
    message = messages[
        1]  # The second message in the list is the one above the command

    # React to the message above the command
    await message.add_reaction("✅")


print(
    f'Pokétwo Autocatcher {version}\nA free and open-source Pokétwo autocatcher Modified by Viwes Bot\nEvent Log:'
)
keep_alive.keep_alive()
client.run(f"{user_token}")
